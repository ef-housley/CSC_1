package org.example;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AppConfig {
    public static String preferredLanguage = "romana";
}
