package org.example.model;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
@Entity
@Table(name = "tickets")
public class Ticket {


    @Id
    @Column(name = "ticket_number", nullable = false)
    private Integer ticketNumber;

    @Column(name = "train")
    private Integer train;

    @Column(name = "place", nullable = false)
    private Integer place;

    @Column(name = "price", nullable = false)
    private Double price;

}
