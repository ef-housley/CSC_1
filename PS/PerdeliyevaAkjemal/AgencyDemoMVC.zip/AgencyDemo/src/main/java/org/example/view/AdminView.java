package org.example.view;
import lombok.Getter;
import lombok.Setter;
import javax.swing.*;
import java.awt.*;

@Getter
@Setter
public class AdminView extends JFrame{

    private JTabbedPane adminTabbedPane;
    private JPanel mainPanelAdmin;
    private JPanel listUserPanel;
    private JPanel crudUserPanel;
    private JButton retrieveUserButton;
    private JButton deleteUserButton;
    private JButton insertUserButton;
    private JButton updateUserButton;
    private JTable authenticatedUsersTable;
    private JTable newUsersTable;
    private JPanel authorizePanel;
    private JButton authorizeButton;
    private JTextField usernameField;
    private JTextField passwordField;
    private JTextField roleField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField cnpField;
    private JButton saveUserButton;
    private JFrame addUserFrame;
    public AdminView(String username) {
        setTitle(username);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        add(mainPanelAdmin);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void initInsertForm(){
        addUserFrame = new JFrame("Add New User");
        addUserFrame.setSize(400, 300);
        addUserFrame.setLocationRelativeTo(null);

        JPanel formPanel = new JPanel(new GridLayout(7, 2));
        formPanel.add(new JLabel("Username :"));
        usernameField = new JTextField();
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JTextField();
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Role:"));
        roleField = new JTextField();
        formPanel.add(roleField);
        formPanel.add(new JLabel("First Name:"));
        firstNameField = new JTextField();
        formPanel.add(firstNameField);
        formPanel.add(new JLabel("Last Name:"));
        lastNameField = new JTextField();
        formPanel.add(lastNameField);
        formPanel.add(new JLabel("Email :"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("CNP :"));
        cnpField = new JTextField();
        formPanel.add(cnpField);

        saveUserButton = new JButton("Save User");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(saveUserButton);
        addUserFrame.add(formPanel, BorderLayout.CENTER);
        addUserFrame.add(buttonPanel, BorderLayout.SOUTH);
        addUserFrame.setVisible(true);
    }
}
