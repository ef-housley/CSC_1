package org.example;

import org.example.controller.PassengerController;
import org.example.view.PassengerView;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            PassengerView passengerView = new PassengerView("Passenger View");
            PassengerController passengerController = new PassengerController(passengerView);
            passengerController.initPController();

        });
    }
}