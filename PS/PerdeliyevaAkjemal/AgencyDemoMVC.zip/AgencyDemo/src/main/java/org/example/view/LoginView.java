package org.example.view;

import lombok.Getter;
import lombok.Setter;

import javax.swing.*;

@Getter
@Setter
public class LoginView extends JFrame{
    private JPanel mainPanel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel usernameJlabel;
    private JLabel passwordJlabel;

    public LoginView(){
        setTitle("Login Page");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        add(mainPanel);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
