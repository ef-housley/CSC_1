package org.example.view;
import lombok.Getter;
import lombok.Setter;

import javax.swing.*;
import java.awt.*;

@Getter
@Setter
public class EmployeeView extends JFrame {
    private JPanel mainPanel;
    private JTabbedPane tabbedPaneOperation;
    private JPanel sellPanel;
    private JPanel crudPanel;
    private JTabbedPane crudPane;
    private JPanel trainOperationsPanel;
    private JPanel ticketOperationsPanel;
    private JPanel trainOpButtons;
    private JButton RETRIEVEButton;
    private JButton DELETEButton;
    private JButton UPDATEButton;
    private JButton INSERTButton;
    private JTable tableForTrains;
    private JButton retrieveTicketsButton;
    private JButton deleteTicketButton;
    private JButton insertTicketButton;
    private JButton updateTicketButton;
    private JTable ticketsTable;
    private JTextField PlaceField;
    private JTextField PriceField;
    private JButton SELLButton;
    private JLabel ticketLabel;
    private JLabel trainLabel;
    private JLabel placeLabel;
    private JLabel PriceLabel;
    private JTextField trainNumberField;
    private JTextField departureStationField;
    private JTextField destinationField;
    private JTextField departureTimeField;
    private JTextField arrivalTimeField;
    private JTextField seatCapacityField;
    private JTextField ticketNumberField;
    private JTextField trainNumberTicketField;
    private JTextField placeJTextField;
    private JTextField priceJtextField;
    private JButton saveButton;
    private JFrame addTrainFrame;
    private JPanel formPanel;
    private JButton saveTicketButton;
    private JFrame addTicketFrame;
    private JPanel formPanelTicket;

    public EmployeeView(String username) {
        setTitle(username);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        add(mainPanel);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public void formInitAddTrain(){
        addTrainFrame = new JFrame("Add Train");
        addTrainFrame.setSize(400, 300);
        addTrainFrame.setLocationRelativeTo(null);

        formPanel = new JPanel(new GridLayout(6, 2));
        formPanel.add(new JLabel("Train Number:"));
        trainNumberField = new JTextField();
        formPanel.add(trainNumberField);
        formPanel.add(new JLabel("Departure Station:"));
        departureStationField = new JTextField();
        formPanel.add(departureStationField);
        formPanel.add(new JLabel("Destination:"));
        destinationField = new JTextField();
        formPanel.add(destinationField);
        formPanel.add(new JLabel("Departure Time:"));
        departureTimeField = new JTextField();
        formPanel.add(departureTimeField);
        formPanel.add(new JLabel("Arrival Time:"));
        arrivalTimeField = new JTextField();
        formPanel.add(arrivalTimeField);
        formPanel.add(new JLabel("Seat Capacity:"));
        seatCapacityField = new JTextField();
        formPanel.add(seatCapacityField);

        saveButton = new JButton("Save");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(saveButton);
        addTrainFrame.add(formPanel, BorderLayout.CENTER);
        addTrainFrame.add(buttonPanel, BorderLayout.SOUTH);
        addTrainFrame.setVisible(true);
    }

    public void formInitAddTicket(){
        addTicketFrame = new JFrame("Add New Ticket");
        addTicketFrame.setSize(400, 300);
        addTicketFrame.setLocationRelativeTo(null);

        formPanelTicket = new JPanel(new GridLayout(4, 2));
        formPanelTicket.add(new JLabel("Ticket Number:"));
        ticketNumberField = new JTextField();
        formPanelTicket.add(ticketNumberField);
        formPanelTicket.add(new JLabel("Train Number:"));
        trainNumberTicketField = new JTextField();
        formPanelTicket.add(trainNumberTicketField);
        formPanelTicket.add(new JLabel("Place on the Train:"));
        placeJTextField = new JTextField();
        formPanelTicket.add(placeJTextField);
        formPanelTicket.add(new JLabel("Price:"));
        priceJtextField=new JTextField();
        formPanelTicket.add(priceJtextField);

        saveTicketButton = new JButton("Save");
        addTicketFrame.add(formPanelTicket, BorderLayout.CENTER);
        addTicketFrame.add(saveTicketButton, BorderLayout.SOUTH);
        addTicketFrame.setVisible(true);
    }



}
