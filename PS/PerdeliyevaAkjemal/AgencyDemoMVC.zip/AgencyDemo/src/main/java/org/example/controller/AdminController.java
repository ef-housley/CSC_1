package org.example.controller;
import org.example.AppConfig;
import org.example.model.User;
import org.example.model.UserRepo;
import org.example.view.AdminView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class AdminController {
    private final AdminView adminView;
    private final UserRepo userRepo;

    public AdminController(AdminView adminView) {
        this.adminView = adminView;
        this.userRepo = new UserRepo();
    }

    public void initAController(){
        updateUI();
        printAuthenticatedUsers();
        printUnauthenticatedUsers();
        adminView.getInsertUserButton().addActionListener(e->{
            adminView.initInsertForm();
            adminView.getSaveUserButton().addActionListener(ee->{
                saveUser();
                adminView.getAddUserFrame().dispose();
            });
        });
        adminView.getRetrieveUserButton().addActionListener(e->{
            printAuthenticatedUsers();
            printUnauthenticatedUsers();
        });
        adminView.getDeleteUserButton().addActionListener(e->deleteUser());
        adminView.getUpdateUserButton().addActionListener(e->updateUser());
        adminView.getAuthorizeButton().addActionListener(e->authorize());
    }

    public void saveUser(){
        String username = adminView.getUsernameField().getText();
        String password = adminView.getPasswordField().getText();
        String role = adminView.getRoleField().getText();
        String firstname = adminView.getFirstNameField().getText();
        String lastname = adminView.getLastNameField().getText();
        String email = adminView.getEmailField().getText();
        Long cnp = Long.parseLong(adminView.getCnpField().getText());

        User user = new User(username,password,role,firstname,lastname,email,cnp);
        userRepo.save(user);
    }
    public void printAuthenticatedUsers(){
        List<User> users = userRepo.getUsersWithUsername();
        List<String[]> userData = new ArrayList<>();
        for(User user : users){
            String username = user.getUsername();
            String password = user.getPassword();
            String role = user.getRole();
            String firstname = user.getFirstName();
            String lastname = user.getLastName();
            String email = user.getEmail();
            String cnp =String.valueOf(user.getCnp());

            String[] data = {username, password, role, firstname, lastname, email, cnp};
            userData.add(data);
        }
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Username");
        model.addColumn("Password");
        model.addColumn("Role");
        model.addColumn("First Name");
        model.addColumn("Last Name");
        model.addColumn("Email");
        model.addColumn("CNP");
        for (String[] data : userData){
            model.addRow(data);
        }
        adminView.getAuthenticatedUsersTable().setModel(model);
        adminView.getAuthenticatedUsersTable().createDefaultColumnsFromModel();
    }

    public void printUnauthenticatedUsers(){
        List<User> users = userRepo.getUsersWithNoUsername();
        List<String[]> userData = new ArrayList<>();
        for(User user : users){
            String firstname = user.getFirstName();
            String lastname = user.getLastName();
            String email = user.getEmail();
            String cnp =String.valueOf(user.getCnp());

            String[] data = {firstname, lastname, email, cnp};
            userData.add(data);
        }
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("First Name");
        model.addColumn("Last Name");
        model.addColumn("Email");
        model.addColumn("CNP");
        for (String[] data : userData){
            model.addRow(data);
        }
        adminView.getNewUsersTable().setModel(model);
        adminView.getNewUsersTable().createDefaultColumnsFromModel();
    }

    public void updateUser(){

        String username = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 0);
        String password = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 1);
        String role = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 2);
        String firstname = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 3);
        String lastname = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 4);
        String email= (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 5);
        String  cnpStr = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 6);
        long cnp = Long.parseLong(cnpStr);

        User user = new User(username,password,role,firstname,lastname,email,cnp);
        userRepo.updateUser(user);
        printAuthenticatedUsers();
        printUnauthenticatedUsers();
    }

    public void authorize(){

        String username = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 0);
        String password = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 1);
        String role = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 2);
        String firstname = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 3);
        String lastname = (String)adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 4);
        String email= (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 5);
        String  cnpStr = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 6);
        long cnp = Long.parseLong(cnpStr);

        User user = new User(username,password,role,firstname,lastname,email,cnp);
        userRepo.updateUser(user);
        printAuthenticatedUsers();
        printUnauthenticatedUsers();
    }

    public int selectedRow(){
        int selectedRow = adminView.getAuthenticatedUsersTable().getSelectedRow();
        if (selectedRow == -1) {
            return 0;
        }else return selectedRow;
    }
    public void deleteUser(){
        String cnpStr = (String) adminView.getAuthenticatedUsersTable().getValueAt(selectedRow(), 6);
        long cnpInt = Long.parseLong(cnpStr);
        userRepo.deleteUser(cnpInt);
        printAuthenticatedUsers();
        printUnauthenticatedUsers();

    }

    private void updateUI() {
        String language = AppConfig.preferredLanguage;
        try{
            if (language.equals("english")){
                Locale.setDefault(new Locale("en", "US"));
            } else if (language.equals("romana")) {
                Locale.setDefault(new Locale("ro", "RO"));
            }else {
                Locale.setDefault(new Locale("de", "DE"));
            }
            ResourceBundle r = ResourceBundle.getBundle("messages");
            adminView.getAdminTabbedPane().setTitleAt(0, r.getString("listUserPanel"));
            adminView.getAdminTabbedPane().setTitleAt(1, r.getString("crudUserPanel"));
            adminView.getRetrieveUserButton().setText(r.getString("retrieveUser"));
            adminView.getInsertUserButton().setText(r.getString("insertUser"));
            adminView.getUpdateUserButton().setText(r.getString("updateUser"));
            adminView.getDeleteUserButton().setText(r.getString("deleteUser"));
            adminView.getAuthorizeButton().setText(r.getString("authorizeButton"));


        }catch (Exception e){
            JOptionPane.showMessageDialog(adminView, e.toString());
        }
    }
}
