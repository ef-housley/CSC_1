package org.example.model;

import javax.persistence.*;
import java.util.List;

public class TicketRepo {
    @PersistenceContext
    public
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
    public EntityManager em = emf.createEntityManager();

    public void deleteTicket(int ticketNumber) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Ticket ticket = em.find(Ticket.class, ticketNumber);
        if (ticket != null) {
            em.remove(ticket);
        }
        transaction.commit();
    }

    public Ticket findById(int id){
        return em.find(Ticket.class, id);
    }

    public List<Ticket> getAllTickets() {
        TypedQuery<Ticket> query = em.createQuery("SELECT t FROM Ticket t", Ticket.class);
        List<Ticket> tickets = query.getResultList();
        return tickets;
    }

    public Ticket save(Ticket newTicket) {
        em.getTransaction().begin();
        em.persist(newTicket);
        em.getTransaction().commit();
        return newTicket;
    }

    public void updateTicket(Ticket updatedTicket) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Ticket ticket = em.find(Ticket.class, updatedTicket.getTicketNumber());
        em.merge(updatedTicket);
        transaction.commit();
    }
}
