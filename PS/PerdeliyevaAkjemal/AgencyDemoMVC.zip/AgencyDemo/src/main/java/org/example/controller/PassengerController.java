package org.example.controller;
import org.example.AppConfig;
import org.example.model.Train;
import org.example.model.TrainRepo;
import org.example.view.LoginView;
import org.example.view.PassengerView;
import javax.swing.*;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class PassengerController {
    private final PassengerView passengerView;
    private final TrainRepo trainRepo;

    public PassengerController(PassengerView passengerView) {
        this.passengerView = passengerView;
        trainRepo = new TrainRepo();
    }

    public void initPController(){
        updateUI("romana");
        passengerView.getSearchByIdButton().addActionListener(e -> seeTrainByNumber());
        passengerView.getSearchByStationsButton().addActionListener(e->seeTrainByStations());
        passengerView.getLoginButton().addActionListener(e->setLoginView());
        passengerView.getEngButton().addActionListener(e -> {
            updateUI("english");
            AppConfig.preferredLanguage = "english";
        });
        passengerView.getRoButton().addActionListener(e -> {
            updateUI("romana");
            AppConfig.preferredLanguage = "romana";
        });
        passengerView.getDeButton().addActionListener(e->{
            updateUI("german");
            AppConfig.preferredLanguage = "german";
        });
    }

    public void seeTrainByNumber(){
        String idStr = passengerView.getIntroduceTrainId().getText();
        Train train = trainRepo.getById(Integer.parseInt(idStr));
        if(train == null){
            JOptionPane.showMessageDialog(this.passengerView, "train is empty");
        }else {
            passengerView.getTextPane1().setText(train.toString());
        }
    }

    public void seeTrainByStations(){
        String departureStation = passengerView.getDepartureTextField().getText();
        String destination = passengerView.getDestinationTextField().getText();
        List<Train> trains = trainRepo.getByStations(departureStation, destination);
        if(trains.isEmpty()){
            JOptionPane.showMessageDialog(this.passengerView, "No trains found for specified stations");
        }else {
            DefaultListModel<String> modelTrain = new DefaultListModel<>();
            for(Train tr : trains) {
                String trainStr = tr.toString();
                modelTrain.addElement(trainStr);
            }
            passengerView.getList1().setModel(modelTrain);
        }
    }

    public void setLoginView() {
        LoginView loginView= new LoginView();
        LoginController loginController = new LoginController(loginView);
        loginController.initLController();
    }



    private void updateUI(String language) {
        try{
            if(language.equals("english")){
                Locale.setDefault(new Locale("en", "US"));
            } else if (language.equals("romana")) {
                Locale.setDefault(new Locale("ro", "RO"));
            }else {
                Locale.setDefault(new Locale("de", "DE"));
            }
            ResourceBundle r = ResourceBundle.getBundle("messages");
            passengerView.setTitle(r.getString("jPanel1"));
            passengerView.getWelcomeLabel().setText(r.getString("welcomeLabel"));
            passengerView.getLoginButton().setText(r.getString("loginButton"));
            passengerView.getSearchByIdButton().setText(r.getString("searchByIdButton"));
            passengerView.getTabbedPane1().setTitleAt(0, r.getString("byIdPanel"));
            passengerView.getRoButton().setText(r.getString("roButton"));
            passengerView.getEngButton().setText(r.getString("engButton"));
            passengerView.getDeButton().setText(r.getString("deButton"));
            passengerView.getTabbedPane1().setTitleAt(1, r.getString("byStationsPanel"));
            passengerView.getSearchByStationsButton().setText(r.getString("searchByStationsButton"));

        }catch (Exception e){
            JOptionPane.showMessageDialog(passengerView, e.toString());
        }
    }
}
