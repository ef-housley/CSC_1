package org.example.controller;

import org.example.AppConfig;
import org.example.model.User;
import org.example.model.UserRepo;
import org.example.view.AdminView;
import org.example.view.EmployeeView;
import org.example.view.LoginView;

import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginController {
    private final LoginView loginView;
    private final UserRepo userRepo;

    public LoginController(LoginView loginView) {
        this.loginView = loginView;
        this.userRepo = new UserRepo();
    }

    public void initLController(){
        updateUI();
        loginView.getLoginButton().addActionListener(e->login());
    }

    public void login() {
        String username = loginView.getUsernameField().getText();
        char[] passwordChars = loginView.getPasswordField().getPassword();
        String password = new String(passwordChars);
        User u = userRepo.findUser(username, password);
        if (u == null)
            JOptionPane.showMessageDialog(this.loginView, "error user doesnt exist");
        else {
            if (u.getRole().equals("admin")) {
                AdminView adminView = new AdminView(u.getUsername());
                AdminController adminController = new AdminController(adminView);
                adminController.initAController();
                loginView.dispose();
            } else if (u.getRole().equals("employee")) {
                EmployeeView employeeView = new EmployeeView(u.getUsername());
                EmployeeController employeeController = new EmployeeController(employeeView);
                employeeController.initEController();
                loginView.dispose();
            }
        }
    }

    private void updateUI() {
        String language = AppConfig.preferredLanguage;
        try{
            if (language.equals("english")){
                Locale.setDefault(new Locale("en", "US"));
            } else if (language.equals("romana")) {
                Locale.setDefault(new Locale("ro", "RO"));
            }else {
                Locale.setDefault(new Locale("de", "DE"));
            }
            ResourceBundle r = ResourceBundle.getBundle("messages");
            loginView.getUsernameJlabel().setText(r.getString("usernameJlabel"));
            loginView.getPasswordJlabel().setText(r.getString("passwordJlabel"));
            loginView.getLoginButton().setText(r.getString("loginButton"));
            loginView.setTitle(r.getString("mainPanel"));
        }catch (Exception e){
            JOptionPane.showMessageDialog(loginView, e.toString());
        }
    }
}
