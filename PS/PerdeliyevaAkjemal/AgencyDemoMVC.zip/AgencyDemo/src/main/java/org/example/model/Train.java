package org.example.model;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "trains")
public class Train {
    @Id
    @Column(name = "train_number", nullable = false)
    private int trainNumber;
    @Column(name = "departure_station")
    String departureStation;
    @Column(name = "destination")
    String destination;
    @Column(name = "departure_time",nullable = false)
    Date departureTime;
    @Column(name = "arrival_time", nullable = false)
    Date arrivalTime;
    @Column(name = "number_seat")
    int seatCapacity;
}
