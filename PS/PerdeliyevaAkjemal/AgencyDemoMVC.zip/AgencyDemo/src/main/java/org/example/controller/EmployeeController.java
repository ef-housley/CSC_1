package org.example.controller;

import org.example.AppConfig;
import org.example.model.*;
import org.example.view.EmployeeView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class EmployeeController {
    private final TrainRepo trainRepo;
    private final TicketRepo ticketRepo;
    private final EmployeeView employeeView;

    public EmployeeController(EmployeeView employeeView) {
        this.employeeView = employeeView;
        this.trainRepo = new TrainRepo();
        this.ticketRepo = new TicketRepo();
    }

    public void initEController() {
        updateUI();
        printTrains();
        printTickets();
        employeeView.getINSERTButton().addActionListener(e -> {
            employeeView.formInitAddTrain();
            employeeView.getSaveButton().addActionListener((ActionEvent ee) -> {
                try {
                    saveTrain();
                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                }
                employeeView.getAddTrainFrame().dispose();
            });
        });
        employeeView.getRETRIEVEButton().addActionListener(e -> printTrains());
        employeeView.getUPDATEButton().addActionListener(e -> updateTrain());
        employeeView.getDELETEButton().addActionListener(e -> deleteTrain());
        employeeView.getRetrieveTicketsButton().addActionListener(e->printTickets());
        employeeView.getInsertTicketButton().addActionListener(e->{
            employeeView.formInitAddTicket();
            employeeView.getSaveTicketButton().addActionListener(ee-> {
                try {
                    saveTicket();
                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                }
                employeeView.getAddTicketFrame().dispose();
            });
        });
        employeeView.getDeleteTicketButton().addActionListener(e->deleteTicket());
        employeeView.getUpdateTicketButton().addActionListener(e->updateTicket());
        employeeView.getSELLButton().addActionListener(e->sellTicket());
    }

    public void saveTrain() throws ParseException {
        int trainNumberInt = Integer.parseInt(employeeView.getTrainNumberField().getText());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date departureTime = dateFormat.parse(employeeView.getDepartureTimeField().getText());
        Date arrivalTime = dateFormat.parse(employeeView.getArrivalTimeField().getText());
        int seatCapacityInt = Integer.parseInt(employeeView.getSeatCapacityField().getText());
        String departureStation = employeeView.getDepartureStationField().getText();
        String destination = employeeView.getDestinationField().getText();

        Train newTrain = new Train(trainNumberInt, departureStation, destination, departureTime, arrivalTime, seatCapacityInt);
        trainRepo.save(newTrain);
    }


    public void printTrains() {
        List<Train> trains = trainRepo.getAll();
        List<String[]> trainData = new ArrayList<>();
        for (Train train : trains) {
            String trainNumber = String.valueOf(train.getTrainNumber());
            String departureStation = train.getDepartureStation();
            String destination = train.getDestination();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String departureTime = dateFormat.format(train.getDepartureTime());
            String arrivalTime = dateFormat.format(train.getArrivalTime());
            String seatCapacity = String.valueOf(train.getSeatCapacity());
            String[] data = {trainNumber, departureStation, destination, departureTime, arrivalTime, seatCapacity};
            trainData.add(data);
        }
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Train Number");
        model.addColumn("Departure Station");
        model.addColumn("Departure Time");
        model.addColumn("Destination");
        model.addColumn("Arrival Time");
        model.addColumn("Seat Capacity");
        for (String[] data : trainData) {
            model.addRow(data);
        }
        employeeView.getTableForTrains().setModel(model);
        employeeView.getTableForTrains().createDefaultColumnsFromModel();
    }
    public int getSelectedRow(){
        int selectedRow = employeeView.getTableForTrains().getSelectedRow();
        if (selectedRow == -1) {
            return 0;
        }else return selectedRow;
    }

    public void updateTrain() {
        String trainNumberStr = (String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 0);
        int trainNumberInt = Integer.parseInt(trainNumberStr);
        String departureStation = (String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 1);
        String destination = (String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 2);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date departureTime = null;
        Date arrivalTime = null;
        try {
            departureTime = dateFormat.parse((String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 3));
            arrivalTime = dateFormat.parse((String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 4));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String seatCapacityStr = (String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 5);
        int seatCapacityInt = Integer.parseInt(seatCapacityStr);

        Train updatedTrain = new Train(trainNumberInt, departureStation, destination, departureTime, arrivalTime, seatCapacityInt);
        trainRepo.updateTrain(updatedTrain);
        printTrains();
    }


    public void deleteTrain() {
        String trainNumberStr = (String) employeeView.getTableForTrains().getValueAt(getSelectedRow(), 0);
        int trainNumberInt = Integer.parseInt(trainNumberStr);
        trainRepo.deleteTrain(trainNumberInt);
        printTrains();
    }

    public void printTickets() {
        List<Ticket> tickets = ticketRepo.getAllTickets();
        List<String[]> ticketData = new ArrayList<>();
        for (Ticket ticket : tickets) {
            String ticketNumber = String.valueOf(ticket.getTicketNumber());
            String trainNumber = String.valueOf(ticket.getTrain());
            String place= String.valueOf(ticket.getPlace());
            String price = String.valueOf(ticket.getPrice());
            String[] data = {ticketNumber, trainNumber, place, price};
            ticketData.add(data);
        }
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Ticket Number");
        model.addColumn("Train Number");
        model.addColumn("Place Number");
        model.addColumn("Price");
        for (String[] data : ticketData) {
            model.addRow(data);
        }
        employeeView.getTicketsTable().setModel(model);
        employeeView.getTicketsTable().createDefaultColumnsFromModel();
    }

    public int getSelectedTicketRow(){
        int selectedTicketRow = employeeView.getTicketsTable().getSelectedRow();
        if (selectedTicketRow == -1) {
            return 0;
        }else return selectedTicketRow;
    }
    public void deleteTicket() {
        String ticketNumberStr = (String) employeeView.getTicketsTable().getValueAt(getSelectedTicketRow(), 0);
        int ticketNumberInt = Integer.parseInt(ticketNumberStr);
        ticketRepo.deleteTicket(ticketNumberInt);
        printTickets();
    }

    public void saveTicket() throws ParseException{
        Integer ticketNumber = Integer.parseInt(employeeView.getTicketNumberField().getText());
        Integer trainNumber = Integer.parseInt(employeeView.getTrainNumberTicketField().getText());
        int place = Integer.parseInt(employeeView.getPlaceJTextField().getText());
        Double price = Double.parseDouble(employeeView.getPriceJtextField().getText());


        Ticket newTicket = new Ticket(ticketNumber, trainNumber, place, price);
        ticketRepo.save(newTicket);
        printTickets();
    }

    public void updateTicket() {
        String ticketNumberStr = (String) employeeView.getTicketsTable().getValueAt(getSelectedTicketRow(), 0);
        int ticketNumberInt = Integer.parseInt(ticketNumberStr);
        String trainNumberTicketStr = (String)employeeView.getTicketsTable().getValueAt(getSelectedTicketRow(), 1);
        int trainNumberTicketInt = Integer.parseInt(trainNumberTicketStr);
        String placeTicketStr = (String)employeeView.getTicketsTable().getValueAt(getSelectedTicketRow(), 2);
        int placeTicketInt = Integer.parseInt(placeTicketStr);
        String priceStr = (String)employeeView.getTicketsTable().getValueAt(getSelectedTicketRow(), 3);
        double priceDb = Double.parseDouble(priceStr);

        Ticket updatedTicket = new Ticket(ticketNumberInt, trainNumberTicketInt, placeTicketInt, priceDb);
        ticketRepo.updateTicket(updatedTicket);
        printTickets();
    }

    public void sellTicket(){
        int ticketNumber  = Integer.parseInt(employeeView.getTicketNumberField().getText());
        int trainNumber = Integer.parseInt(employeeView.getTrainNumberField().getText());
        int place = Integer.parseInt(employeeView.getPlaceField().getText());
        double price = Double.parseDouble(employeeView.getPriceField().getText());
        if (ticketRepo.findById(ticketNumber) == null) {
            if (trainRepo.getById(trainNumber) != null){
                if (trainRepo.trainCapacity(trainNumber)>=place) {
                    Ticket ticketSold = new Ticket(ticketNumber, trainNumber, place, price);
                    ticketRepo.save(ticketSold);
                    JOptionPane.showMessageDialog(employeeView, "SUCCESS");
                }
            }
        } else {
            JOptionPane.showMessageDialog(employeeView, "error, check ticketNumber, TrainNumber or place");
        }
    }


    private void updateUI() {
        String language = AppConfig.preferredLanguage;
        try{
            if ("english".equals(language)){
                Locale.setDefault(new Locale("en", "US"));
            } else if (language.equals("romana")) {
                Locale.setDefault(new Locale("ro", "RO"));
            }else {
                Locale.setDefault(new Locale("de", "DE"));
            }
            ResourceBundle r = ResourceBundle.getBundle("messages");
            employeeView.getTabbedPaneOperation().setTitleAt(0, r.getString("tab1"));
            employeeView.getTabbedPaneOperation().setTitleAt(1, r.getString("tab2"));
            employeeView.getTicketLabel().setText(r.getString("ticketNumber"));
            employeeView.getTrainLabel().setText(r.getString("trainNumber"));
            employeeView.getPlaceLabel().setText(r.getString("place"));
            employeeView.getPriceLabel().setText(r.getString("price"));
            employeeView.getSELLButton().setText(r.getString("sellButton"));
            employeeView.getCrudPane().setTitleAt(0, r.getString("trainOperations"));
            employeeView.getCrudPane().setTitleAt(1, r.getString("ticketOperations"));
            employeeView.getRETRIEVEButton().setText(r.getString("retrieve"));
            employeeView.getINSERTButton().setText(r.getString("insert"));
            employeeView.getUPDATEButton().setText(r.getString("update"));
            employeeView.getDELETEButton().setText(r.getString("delete"));
            employeeView.getRetrieveTicketsButton().setText(r.getString("retrieve"));
            employeeView.getInsertTicketButton().setText(r.getString("insert"));
            employeeView.getUpdateTicketButton().setText(r.getString("update"));
            employeeView.getDeleteTicketButton().setText(r.getString("delete"));

        }catch (Exception e){
            JOptionPane.showMessageDialog(employeeView, e.toString());
        }
    }
}
