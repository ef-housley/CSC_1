package org.example.model;

import javax.persistence.*;
import java.util.List;

public class UserRepo {
    @PersistenceContext
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
    EntityManager em = emf.createEntityManager();

    public User findUser(String username, String password){
        TypedQuery<User> query = em.createQuery(
                "SELECT u FROM User u WHERE u.username = :username AND u.password = :password", User.class);
        query.setParameter("username", username);
        query.setParameter("password", password);
        User user = query.getSingleResult();
        if (user==null) {
            return null;
        } else {
            return user;
        }
    }

    public List<User> getUsersWithNoUsername() {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.username IS NULL", User.class);
        List<User> usersWithNoUsername = query.getResultList();
        return usersWithNoUsername;
    }

    public List<User> getUsersWithUsername() {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.username IS NOT NULL", User.class);
        List<User> usersWithUsername = query.getResultList();
        return usersWithUsername;
    }


    public void save(User user) {
        em.getTransaction().begin();
        if (user.getUsername().equals("")||user.getPassword().equals("")||user.getRole().equals("")) {
            user = new User (user.getFirstName(), user.getLastName(), user.getEmail(), user.getCnp());
        }else {
            user = new User (user.getUsername(), user.getPassword(), user.getRole(), user.getFirstName(), user.getLastName(), user.getEmail(), user.getCnp());
        }
        em.persist(user);
        em.getTransaction().commit();
    }

    public void deleteUser(long cnpInt) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        User user = em.find(User.class, cnpInt);
        if (user != null) {
            em.remove(user);
        }
        transaction.commit();
    }

    public void updateUser(User userTaken) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        User user = em.find(User.class, userTaken.getCnp());
        em.merge(userTaken);
        transaction.commit();
    }
}
