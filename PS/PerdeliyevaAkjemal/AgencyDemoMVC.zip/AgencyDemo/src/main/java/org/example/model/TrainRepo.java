package org.example.model;

import org.jetbrains.annotations.NotNull;

import javax.persistence.*;
import java.util.List;

public class TrainRepo {
    @PersistenceContext
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
    EntityManager em = emf.createEntityManager();

    public Train save(Train train) {
        em.getTransaction().begin();
        em.persist(train);
        em.getTransaction().commit();
        return train;
    }

    public int trainCapacity(int trainNumber){
        Train train = em.find(Train.class, trainNumber);
        if(train != null){
            return train.getSeatCapacity();
        } else {
            return -1;
        }
    }

    public Train getById(int id) {
        return em.find(Train.class, id);
    }

    public List<Train> getByStations(String departureStation, String destination) {
        TypedQuery<Train> query = em.createQuery("SELECT t FROM Train t WHERE t.departureStation = :departureStation " +
                "AND t.destination = :destination", Train.class);
        query.setParameter("departureStation", departureStation);
        query.setParameter("destination", destination);
        List<Train> trains = query.getResultList();
        return trains;
    }

    public List<Train> getAll() {
        TypedQuery<Train> query = em.createQuery("SELECT t FROM Train t", Train.class);
        List<Train> trains = query.getResultList();
        return trains;
    }

    public void updateTrain(@NotNull Train trainTaken) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Train train = em.find(Train.class, trainTaken.getTrainNumber());
        em.merge(trainTaken);
        transaction.commit();
    }

    public void deleteTrain(int trainNumber) {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Train train = em.find(Train.class, trainNumber);
        if (train != null) {
            em.remove(train);
        }
        transaction.commit();
    }


}
