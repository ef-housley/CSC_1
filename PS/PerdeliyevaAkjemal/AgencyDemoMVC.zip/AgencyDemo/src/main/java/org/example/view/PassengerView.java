package org.example.view;

import lombok.Getter;
import lombok.Setter;

import javax.swing.*;
import java.awt.*;
@Getter
@Setter
public class PassengerView extends JFrame {
    private JPanel jPanel1;
    private JTextField introduceTrainId;
    private JButton loginButton;
    private JTabbedPane tabbedPane1;
    private JPanel byIdPanel;
    private JPanel byStationsPanel;
    private JTextPane textPane1;
    private JTextField departureTextField;
    private JTextField destinationTextField;
    private JButton searchByIdButton;
    private JButton searchByStationsButton;
    private JList list1;
    private JPanel loginBackPanel;
    private JButton roButton;
    private JLabel welcomeLabel;
    private JButton deButton;
    private JButton engButton;
    private JTextField usernameField ;
    private JTextField passwordField ;
    ButtonGroup btgroup;

    public PassengerView(String title) throws HeadlessException {
        super(title);
        btgroup = new ButtonGroup();
        btgroup.add(roButton);
        btgroup.add(engButton);
        btgroup.add(deButton);
        jPanel1.setLayout(new BorderLayout(0,1));
        jPanel1.add(tabbedPane1, BorderLayout.CENTER);
        jPanel1.add(loginBackPanel, BorderLayout.NORTH);
        welcomeLabel.setText("WELCOME TO OUR AGENCY !");

        jPanel1.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        add(jPanel1, BorderLayout.NORTH);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(600, 600);
        setMinimumSize(new Dimension(350, 450));
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
