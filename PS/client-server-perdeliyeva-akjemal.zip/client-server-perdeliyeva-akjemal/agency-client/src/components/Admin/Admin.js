import React, { useState, useEffect } from 'react';

const Admin = () => {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({
    firstname: '',
    lastname: '',
    email: '',
    cnp: '',
    username: '',
    password: '',
    role: '', 
  });
  const [selectedUser, setSelectedUser] = useState(null);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [userToDelete, setUserToDelete] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(null);

  const retrieveUsers = () => {
    fetch('http://localhost:8082/admin/getAllUsers')
      .then(response => response.json())
      .then(data => {
        console.log(data);
        // Handle null values for username and password properties
        const filteredData = data.map(user => ({
          ...user,
          username: user.username || 'N/A',
          password: user.password || 'N/A'
        }));

        setUsers(filteredData);
      })
      .catch(error => console.error('Error retrieving users:', error));
  };

  useEffect(() => {
    retrieveUsers();
  }, []);

  const handleNewUserChange = e => {
    const { name, value } = e.target;
    setNewUser(prevUser => ({
      ...prevUser,
      [name]: value,
    }));
  };

  const addUser = () => {
    fetch('http://localhost:8082/admin/addUser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newUser),
    })
      .then(response => response.json())
      .then(data => {
        setUsers(prevUsers => [data, ...prevUsers]);
        setNewUser({
          firstname: '',
          lastname: '',
          email: '',
          username: '',
          password: '',
          role: '',
        });
      })
      .catch(error => console.error('Error adding user:', error));
  };

  const handleUserRowClick = user => {
    setSelectedUser(user);
  };

  const handleEditUser = user => {
    setIsEditing(true);
    setEditedUser(user);
  };

  const handleSaveUser = () => {
    fetch(`http://localhost:8082/admin/updateUser/${editedUser.cnp}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(editedUser),
    })
      .then(response => response.json())
      .then(updatedUser => {
        setUsers(prevUsers =>
          prevUsers.map(user => (user.cnp === updatedUser.cnp ? updatedUser : user))
        );
        setIsEditing(false);
        setEditedUser(null);
      })
      .catch(error => console.error('Error updating user:', error));
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedUser(null);
  };

  const handleEditedUserChange = e => {
    const { name, value } = e.target;
    setEditedUser(prevUser => ({
      ...prevUser,
      [name]: value,
    }));
  };

  const handleConfirmDelete = () => {
    const cnpToDelete = userToDelete;
    fetch(`http://localhost:8082/admin/deleteUser/${cnpToDelete}`, {
      method: 'PUT',
    })
      .then(response => {
        if (response.ok) {
          setUsers(prevUsers =>
            prevUsers.filter(user => user.username !== cnpToDelete)
          );
          setShowConfirmationDialog(false);
          setUserToDelete('');
        } else {
          throw new Error('Error deleting user.');
        }
      })
      .catch(error => console.error('Error deleting user:', error));
  };

  const handleCancelDelete = () => {
    setShowConfirmationDialog(false);
    setUserToDelete('');
  };

  return (
    <div>
      <h1>Welcome Admin</h1>
      {/* User operations UI */}
      <div className="buttonGroup">
        <button type="button" className="btn btn-outline-secondary" onClick={retrieveUsers}>
          Retrieve Users
        </button>
        <button type="button" className="btn btn-outline-secondary" onClick={addUser}>
          Insert User
        </button>
        {isEditing ? (
          <>
            <button type="button" className="btn btn-outline-secondary" onClick={handleSaveUser}>
              Save User
            </button>
            <button type="button" className="btn btn-outline-secondary" onClick={handleCancelEdit}>
              Cancel Edit
            </button>
          </>
        ) : (
          <button
            type="button"
            className="btn btn-outline-secondary"
            onClick={() => setShowConfirmationDialog(true)}
          >
            Delete User
          </button>
        )}
      </div>

      <table className="table">
        <thead>
          <tr>
            <th scope="col">CNP</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
            <th scope="col">Email</th>
            <th scope="col">Username</th>
            <th scope="col">Password</th>
            <th scope="col">Role</th>
          </tr>
        </thead>
        <tbody className="table-group-divider">
          <tr>
            <td>
              <input
                type="text"
                name="cnp"
                value={newUser?.cnp || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="firstname"
                value={newUser?.firstname || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="lastname"
                value={newUser?.lastname || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="email"
                value={newUser?.email || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="username"
                value={newUser?.username || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="password"
                name="password"
                value={newUser?.password || ''}
                onChange={handleNewUserChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="role"
                value={newUser?.role || ''}
                onChange={handleNewUserChange}
              />
            </td>
          </tr>
          {users.map(user => (
            <tr
              key={user.username}
              onClick={() => handleUserRowClick(user)}
              className={`${user.username === 'N/A' || user.password === 'N/A' ? 'red-bg' : ''}`}
            >
              <td>
                {isEditing && editedUser?.cnp === user?.cnp ? (
                  <input
                    type="text"
                    name="cnp"
                    value={editedUser?.cnp || ''}
                    onChange={handleEditedUserChange}
                  />
                ) : (
                  user?.cnp || ''
                )}
              </td>
              <td>
                {isEditing && editedUser?.cnp === user?.cnp ? (
                  <input
                    type="text"
                    name="firstname"
                    value={editedUser?.firstname || ''}
                    onChange={handleEditedUserChange}
                  />
                ) : (
                  user?.firstname || ''
                )}
              </td>
              <td>
                {isEditing && editedUser?.cnp === user?.cnp ? (
                  <input
                    type="text"
                    name="lastname"
                    value={editedUser?.lastname || ''}
                    onChange={handleEditedUserChange}
                  />
                ) : (
                  user?.lastname || ''
                )}
              </td>
              <td>
                {isEditing && editedUser?.cnp === user?.cnp ? (
                  <input
                    type="text"
                    name="email"
                    value={editedUser?.email || ''}
                    onChange={handleEditedUserChange}
                  />
                ) : (
                  user?.email || ''
                )}
              </td>
              <td>{user?.username || ''}</td>
              <td>{user?.password || ''}</td>
              <td>{user?.role || ''}</td>
              {selectedUser?.cnp === user?.cnp && !isEditing && (
                <td>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handleEditUser(user)}
                  >
                    Edit
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      {/* Confirmation Dialog */}
      {showConfirmationDialog && (
        <div className="confirmation-dialog">
          <p>Enter the CNP number to delete:</p>
          <input
            type="text"
            value={userToDelete}
            onChange={(e) => setUserToDelete(e.target.value)}
          />

          <button type="button" className="btn btn-primary" onClick={handleConfirmDelete}>
            Delete
          </button>
          <button type="button" className="btn btn-secondary" onClick={handleCancelDelete}>
            Cancel
          </button>
        </div>
      )}
    </div>
  );
};

export default Admin;
