import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Body from './Body';
import Login from '../Login/Login';

const Passenger = () => {
  return (
    <div>
      <h1 className="display-3">Welcome to our Agency!</h1>
      <Body />
    </div>
  );
};
export default Passenger;
