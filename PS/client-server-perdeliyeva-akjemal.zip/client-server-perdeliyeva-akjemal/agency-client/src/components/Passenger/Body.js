import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Body = () => {
  const [activeTab, setActiveTab] = useState('nav-home');
  const[trainData, setTrainData] = useState(null);
  const [trainDatas, setTrainDatas] = useState([]);
  const [departureStation, setDepartureStation] = useState('');
  const [destination, setDestination] = useState('');
  const navigate = useNavigate();


  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
  };

  const handleSearch = async () => {
    const trainNumber = document.getElementById('trainNumber').value;
    try {
      const response = await axios.get(`http://localhost:8082/passenger/${trainNumber}`);
      setTrainData(response.data);
    } catch (error) {
      console.error(error);
    }
  };
  const handleDepartureStationChange = (e) => {
    setDepartureStation(e.target.value);
  };

  const handleDestinationChange = (e) => {
    setDestination(e.target.value);
  };

  const handleSearchStations = async () => {
    try {
      const response = await axios.get(`http://localhost:8082/passenger/betweenStations/${departureStation}/${destination}`);
      setTrainDatas(response.data);
      setDepartureStation(''); // Clear departureStation input value
      setDestination(''); // Clear destination input value
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogin = () => {
    navigate('/login');
  };
  
  

  return (

    <div className="container">
      <div className="d-grid gap-2 d-md-flex justify-content-md-end">
      <button type="button" className="btn btn-outline-primary" onClick={handleLogin}>
        Login
      </button>
      </div>
      <ul className="nav nav-tabs" id="nav-tab" role="tablist">
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'nav-home' ? 'active' : ''}`}
            id="nav-home-tab"
            data-bs-toggle="tab"
            data-bs-target="#nav-home"
            type="button"
            role="tab"
            aria-controls="nav-home"
            aria-selected={activeTab === 'nav-home'}
            onClick={() => handleTabClick('nav-home')}
          >
            Search train by number
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'nav-profile' ? 'active' : ''}`}
            id="nav-profile-tab"
            data-bs-toggle="tab"
            data-bs-target="#nav-profile"
            type="button"
            role="tab"
            aria-controls="nav-profile"
            aria-selected={activeTab === 'nav-profile'}
            onClick={() => handleTabClick('nav-profile')}
          >
            Search train by Stations
          </button>
        </li>
      </ul>
      <div className="tab-content" id="nav-tabContent">
        <div
          className={`tab-pane fade ${activeTab === 'nav-home' ? 'show active' : ''}`}
          id="nav-home"
          role="tabpanel"
          aria-labelledby="nav-home-tab"
        >
          {/* content */}
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Train Number"
              aria-label="Train Number"
              aria-describedby="button-addon2"
              id="trainNumber"
            />
            <button className="btn btn-outline-secondary" type="button" id="button-addon2" onClick={handleSearch}>
              Search
            </button>
          </div>
          {/* table */}
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Train Number</th>
                <th scope="col">Departure Station</th>
                <th scope="col">Destination</th>
                <th scope="col">Departure Time</th>
                <th scope="col">Arrival Time</th>
                <th scope="col">Capacity</th>
              </tr>
            </thead>
            <tbody className="table-group-divider">
              {trainData && (
                <tr>
                  <th scope="row">{trainData.trainNumber}</th>
                  <td>{trainData.departureStation}</td>
                  <td>{trainData.destination}</td>
                  <td>{new Date(trainData.departureTime).toLocaleDateString()} {new Date(trainData.departureTime).toLocaleTimeString()}</td>
                  <td>{new Date(trainData.arrivalTime).toLocaleDateString()} {new Date(trainData.arrivalTime).toLocaleTimeString()}</td>
                  <td>{trainData.seatCapacity}</td>
                </tr>
              )}
            </tbody>

          </table>
        </div>
        <div
          className={`tab-pane fade ${activeTab === 'nav-profile' ? 'show active' : ''}`}
          id="nav-profile"
          role="tabpanel"
          aria-labelledby="nav-profile-tab"
        >
          {/* content */}
          <div className="input-group mb-3">
            <input
             type="text" 
              className="form-control"
              placeholder="Departure station"
              aria-label="Sizing example input" 
              aria-describedby="inputGroup-sizing-default"
              value={departureStation}
              onChange={handleDepartureStationChange}
            />
          </div>
          <div className="input-group mb-3">
            <input
             type="text" 
              className="form-control"
              placeholder="Destination"
              aria-label="Sizing example input" 
              aria-describedby="inputGroup-sizing-default"
              value={destination}
              onChange={handleDestinationChange}
            />
          </div>
          <button type="button" className="btn btn-outline-secondary" onClick={handleSearchStations}>Search</button>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Train Number</th>
                <th scope="col">Departure Station</th>
                <th scope="col">Destination</th>
                <th scope="col">Departure Time</th>
                <th scope="col">Arrival Time</th>
                <th scope="col">Capacity</th>
              </tr>
            </thead>
            <tbody className="table-group-divider">
              {trainDatas.map((train) => (
                <tr key={train.trainNumber}>
                  <th scope="row">{train.trainNumber}</th>
                  <td>{train.departureStation}</td>
                  <td>{train.destination}</td>
                  <td>{new Date(train.departureTime).toLocaleDateString()} {new Date(train.departureTime).toLocaleTimeString()}</td>
                  <td>{new Date(train.arrivalTime).toLocaleDateString()} {new Date(train.arrivalTime).toLocaleTimeString()}</td>
                  <td>{train.seatCapacity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Body;
