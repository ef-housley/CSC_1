import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    // Perform login logic here
    const response = await fetch(`http://localhost:8082/login?username=${username}&password=${password}`);
    console.log("here", response);
    const data = await response.json();

    if (data.role === 'admin') {
      navigate('/admin');
    } else if (data.role === 'employee') {
      navigate('/employee');
    } else {
      // Handle invalid credentials or other cases
    }
  };

  return (
    <div className='login-container'>
      <div className="form-floating mb-3">
        <input type="email" className="form-control" id="floatingInput" placeholder="name@example.com" value={username} onChange={(e) => setUsername(e.target.value)} />
        <label htmlFor="floatingInput">Username</label>
      </div>
      <div className="form-floating">
        <input type="password" className="form-control" id="floatingPassword" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <label htmlFor="floatingPassword">Password</label>
      </div>
      <div className='loginButton'>
        <button type="button" className="btn btn-outline-primary" onClick={handleLogin}>Login</button>
      </div>
    </div>
  );
};

export default Login;
