import { useState } from "react";
import React from 'react';
import Train from "./Train";
import Ticket from './Ticket';


const Employee = () => {
    
    const [activeTab, setActiveTab] = useState('nav-home');
    const handleTabClick = (tabId) => {
        setActiveTab(tabId);
    };
      
      
    return (
        <div>
            <h1>Welcome, Employee!</h1>
            <ul className="nav nav-tabs">
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === 'nav-home' ? 'active' : ''}`}
                        id="nav-home-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#nav-home"
                        type="button"
                        role="tab"
                        aria-controls="nav-home"
                        aria-selected={activeTab === 'nav-home'}
                        onClick={() => handleTabClick('nav-home')}
                    >
                        Ticket Operations
                    </button>
                </li>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === 'nav-profile' ? 'active' : ''}`}
                        id="nav-profile-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#nav-profile"
                        type="button"
                        role="tab"
                        aria-controls="nav-profile"
                        aria-selected={activeTab === 'nav-profile'}
                        onClick={() => handleTabClick('nav-profile')}
                    >
                        Train Operations
                    </button>
                </li>
            </ul>
            <div className="tab-content" id="nav-tabContent">
                <div
                    className={`tab-pane fade ${activeTab === 'nav-home' ? 'show active' : ''}`}
                    id="nav-home"
                    role="tabpanel"
                    aria-labelledby="nav-home-tab"
                >
                    <Ticket />
                </div>
                <div
                    className={`tab-pane fade ${activeTab === 'nav-profile' ? 'show active' : ''}`}
                    id="nav-profile"
                    role="tabpanel"
                    aria-labelledby="nav-profile-tab"
                >
                    {/* content */}
                    <Train />
            </div>    
        
        </div>
        </div>
    )
    }

export default Employee;
