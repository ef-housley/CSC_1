import React from 'react';
import { useState } from "react";

const Train = () => {
  // Add train operations related code here
  const [isEditing, setIsEditing] = useState(false);
  const [trains, setTrains] = useState([]);
  const [newTrain, setNewTrain] = useState({
    trainNumber: "",
    departureStation: "",
    destination: "",
    departureTime: "",
    arrivalTime: "",
    capacity: ""
  });
  const [selectedTrain, setSelectedTrain] = useState(null);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [trainToDelete, setTrainToDelete] = useState('');

  const handleEditClick = () => {
    setIsEditing(true);
  };

  
  const handleRowClick = (train) => {;
    console.log(train);
  };

  const handleSaveClick = () => {
    setIsEditing(false);
    // Perform save operation for the edited train
    // You can make an API request to update the train data
  };
    
    const retrieveTrains = () => {
        fetch('http://localhost:8082/employee/getAllTrains')
          .then(response => response.json())
          .then(data => setTrains(data))
          .catch(error => console.error('Error retrieving trains:', error));
    };


    
    const parseDateString = (dateString) => {
        if (!dateString) return null;
      
        const [datePart, timePart] = dateString.split(' ');
        const [month, day, year] = datePart.split('/');
        const [hours, minutes] = timePart.split(':');
      
        const parsedDate = new Date(year, month - 1, day, hours, minutes);
        if (isNaN(parsedDate)) return null;
      
        return parsedDate.toISOString();
    };
    
    const handleNewTrainChange = (e) => {
        const { name, value } = e.target;
        setNewTrain((prevTrain) => ({
            ...prevTrain,
            [name]: value,
        }));
    };
    
    const addTrain = () => {
        const parsedDepartureTime = parseDateString(newTrain.departureTime);
        const parsedArrivalTime = parseDateString(newTrain.arrivalTime);
      
        const formattedTrain = {
            ...newTrain,
            departureTime: parsedDepartureTime,
            arrivalTime: parsedArrivalTime,
        };
      
        fetch('http://localhost:8082/employee/addTrain', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formattedTrain),
        })
        .then((response) => response.json())
        .then((data) => {
            setTrains((prevTrains) => [data, ...prevTrains]);
            setNewTrain({
                trainNumber: '',
                departureStation: '',
                destination: '',
                departureTime: '',
                arrivalTime: '',
                capacity: '',
            });
        })
        .catch((error) => console.error('Error adding train: ', error));
    };

      const handleConfirmDelete = () => {
        console.log(trainToDelete);
        const trainNumberToDelete = trainToDelete;
        console.log(trainNumberToDelete);
    
        fetch(`http://localhost:8082/employee/deleteTrain/${trainNumberToDelete}`, {
          method: 'PUT',
        })
          .then((response) => {
            if (response.ok) {
              setTrains((prevTrains) =>
                prevTrains.filter((train) => train.trainNumber !== trainNumberToDelete)
              );
              setShowConfirmationDialog(false);
              setTrainToDelete('');
            } else {
              throw new Error('Error deleting train.');
            }
          })
          .catch((error) => console.error('Error deleting train:', error));
      };
      
      const handleCancelDelete = () => {
        setShowConfirmationDialog(false);
        setTrainToDelete('');
      };

  return (
    <div>
      {/* Train operations UI */}
      <div className="buttonGroup">
            <button type="button" className="btn btn-outline-secondary" onClick={retrieveTrains}>Train Retrieve</button>
            <button type="button" className="btn btn-outline-secondary" onClick={addTrain}>Train Insert</button>
            <button type="button" className="btn btn-outline-secondary">Train Update</button>
            <button type="button" className="btn btn-outline-secondary" onClick={() => setShowConfirmationDialog(true)}>Train Delete</button>

        </div>

        <table className="table">
            <thead>
                <tr>
                    <th scope="col">Train Number</th>
                    <th scope="col">Departure Station</th>
                    <th scope="col">Destination</th>
                    <th scope="col">Departure Time</th>
                    <th scope="col">Arrival Time</th>
                    <th scope="col">Capacity</th>
                </tr>
            </thead>
            <tbody className="table-group-divider">
                <tr>
                    <th scope="row">
                        <input
                            type="text"
                            name="trainNumber"
                            value={newTrain.trainNumber}
                            onChange={handleNewTrainChange}
                        />
                    </th>
                    <td>
                        <input
                            type="text"
                            name="departureStation"
                            value={newTrain.departureStation}
                            onChange={handleNewTrainChange}
                        />
                    </td>
                    <td>
                        <input
                            type="text"
                            name="destination"
                            value={newTrain.destination}
                            onChange={handleNewTrainChange}
                        />
                    </td>
                    <td>
                        <input
                            type="text"
                            name="departureTime"
                            placeholder="MM/DD/YYYY HH:MM"
                            value={newTrain.departureTime}
                            onChange={handleNewTrainChange}
                        />
                    </td>
                    <td>
                        <input
                            type="text"
                            placeholder="MM/DD/YYYY HH:MM"
                            name="arrivalTime"
                            value={newTrain.arrivalTime}
                            onChange={handleNewTrainChange}
                        />
                    </td>
                    <td>
                        <input
                            type="text"
                            name="capacity"
                            value={newTrain.capacity}
                            onChange={handleNewTrainChange}
                        />
                    </td>
                </tr>
                {trains.map((train) => (
                    <tr key={train.trainNumber} onClick={() => handleRowClick(train)}>
                        <th scope="row">{train.trainNumber}</th>
                        <td>{train.departureStation}</td>
                        <td>{train.destination}</td>
                        <td>{new Date(train.departureTime).toLocaleDateString()} {new Date(train.departureTime).toLocaleTimeString()}</td>
                        <td>{new Date(train.arrivalTime).toLocaleDateString()} {new Date(train.arrivalTime).toLocaleTimeString()}</td>
                        <td>{train.seatCapacity}</td>
                    </tr>
                ))}
            </tbody>
        </table>
        {showConfirmationDialog && (
            <div className="confirmation-dialog">
                <p>Enter the train number to delete:</p>
                <input
                type="text"
                value={trainToDelete}
                onChange={(e) => setTrainToDelete(e.target.value)}
                />

                <button type="button" className="btn btn-primary" onClick={handleConfirmDelete}>
                Delete
                </button>
                <button type="button" className="btn btn-secondary" onClick={handleCancelDelete}>
                Cancel
                </button>
            </div>
            )}

    </div>
  );
};

export default Train;