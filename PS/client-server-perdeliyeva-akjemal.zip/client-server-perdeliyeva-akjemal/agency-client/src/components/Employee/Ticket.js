import React, { useState } from 'react';

const Ticket = () => {
    const [tickets, setTickets] = useState([]);
    const [newTicket, setNewTicket] = useState({
      ticketNumber: '',
      seatNumber: '',
      price: '',
      trainNumber: '',
    });
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [showTicketConfirmationDialog, setShowTicketConfirmationDialog] = useState(false);
  const [ticketToDelete, setTicketToDelete] = useState('');

  const retrieveTickets = () => {
    fetch('http://localhost:8082/employee/getAllTickets')
      .then(response => response.json())
      .then(data => setTickets(data))
      .catch(error => console.error('Error retrieving tickets:', error));
  };

  const handleNewTicketChange = (e) => {
    const { name, value } = e.target;
    setNewTicket((prevTicket) => ({
      ...prevTicket,
      [name]: value,
    }));
  };

  const addTicket = () => {
    fetch('http://localhost:8082/employee/addTicket', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newTicket),
    })
      .then((response) => response.json())
      .then((data) => {
        setTickets((prevTickets) => [...prevTickets, data]);
        setNewTicket({
            ticketNumber:0,
          seatNumber: 0,
          price: 0,
          trainNumber: null,
        });
      })
      .catch((error) => console.error('Error adding ticket:', error));
  };

  const handleTicketRowClick = (ticket) => {
    console.log(ticket);
  };

  const handleConfirmTicketDelete = () => {
    fetch(`http://localhost:8082/employee/deleteTicket/${ticketToDelete}`, {
      method: 'PUT',
    })
      .then((response) => {
        if (response.ok) {
          setTickets((prevTickets) =>
            prevTickets.filter((ticket) => ticket.ticketNumber !== ticketToDelete)
          );
          setShowTicketConfirmationDialog(false);
          setTicketToDelete('');
        } else {
          throw new Error('Error deleting ticket.');
        }
      })
      .catch((error) => console.error('Error deleting ticket:', error));
  };

  const handleCancelTicketDelete = () => {
    setShowTicketConfirmationDialog(false);
    setTicketToDelete('');
  };

  return (
    <div>
      {/* Ticket operations UI */}
      <div className="buttonGroup">
        <button type="button" className="btn btn-outline-secondary" onClick={retrieveTickets}>
          Ticket Retrieve
        </button>
        <button type="button" className="btn btn-outline-secondary" onClick={addTicket}>
          Ticket Insert
        </button>
        <button type="button" className="btn btn-outline-secondary">
          Ticket Update
        </button>
        <button
          type="button"
          className="btn btn-outline-secondary"
          onClick={() => setShowTicketConfirmationDialog(true)}
        >
          Ticket Delete
        </button>
      </div>

      <table className="table">
        <thead>
          <tr>
            <th scope="col">Ticket Number</th>
            <th scope="col">Seat Number</th>
            <th scope="col">Price</th>
            <th scope="col">Train Number</th>
          </tr>
        </thead>
        <tbody className="table-group-divider">
          <tr>
            <th scope="row">
              <input
                type="text"
                name="seatNumber"
                value={newTicket.seatNumber}
                onChange={handleNewTicketChange}
              />
            </th>
            <td>
              <input
                type="text"
                name="price"
                value={newTicket.price}
                onChange={handleNewTicketChange}
              />
            </td>
            <td>
              <input
                type="text"
                name="trainNumber"
                value={newTicket.trainNumber}
                onChange={handleNewTicketChange}
              />
            </td>
            <td>
              <button type="button" className="btn btn-success" onClick={addTicket}>
                Add
              </button>
            </td>
          </tr>
          {tickets.map((ticket) => (
            <tr key={ticket.ticketNumber} onClick={() => handleTicketRowClick(ticket)}>
              <th scope="row">{ticket.ticketNumber}</th>
              <td>{ticket.seatNumber}</td>
              <td>{ticket.price}</td>
              <td>{ticket.trainNumber}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Ticket delete confirmation dialog */}
      {showTicketConfirmationDialog && (
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Confirm Ticket Deletion</h5>
              <button
                type="button"
                className="btn-close"
                onClick={handleCancelTicketDelete}
              ></button>
            </div>
            <div className="modal-body">
              <p>Are you sure you want to delete this ticket?</p>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handleCancelTicketDelete}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={handleConfirmTicketDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Ticket;
