import Passenger from './components/Passenger/Passenger';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login/Login';
import Admin from './components/Admin/Admin';
import Employee from './components/Employee/Employee';

function App() {
  return (
    <div className='App'>
      <Router>
        <Routes>
          <Route path = "/" element={<Passenger /> }/>
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/employee" element={<Employee />} />
        </Routes>
      </Router>
     
    </div>
  );
}

export default App;
