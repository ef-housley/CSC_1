package com.example.agencymvp.service;

import com.example.agencymvp.model.Ticket;
import com.example.agencymvp.model.Train;
import com.example.agencymvp.repository.TicketRepo;
import com.example.agencymvp.repository.TrainRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private TrainRepo trainRepo;
    @Autowired
    private TicketRepo ticketRepo;

    public Train addTrain(Train train) {
        return trainRepo.save(train);
    }

    public void deleteTrain(int trainNumber){
        trainRepo.deleteTrainByTrainNumber(trainNumber);

    }

    public List<Train>getAllTrains(){
        return trainRepo.findAll();
    }

    public List<Ticket>getAllTickets(){
        return ticketRepo.findAll();
    }
    //todo: toate permisiuni permise utilizatorilor de tip calator
    //todo: vanzarea biletelor
    //todo  updateTrain, ->trenurilor si biletelor vandute
    //todo: salvarea listelor cu info despre trenuri in format txt
    //todo: vizualizare statistici
}
