package com.example.agencymvp.controller;

import com.example.agencymvp.model.User;
import com.example.agencymvp.service.AdminService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    AdminService adminService;

    @GetMapping("/getAllUsers")
    public List<User> getAllUsers(){
        return adminService.allUsers();
    }
    @PostMapping("/addUser")
    public User addUser(@RequestBody User user) {
        return adminService.addUser(user);
    }

    @Transactional
    @PutMapping("deleteUser/{cnp}")
    public void deleteUser(@PathVariable(value = "cnp") long cnp) {
        adminService.deleteUser(cnp);
    }

    @Transactional
    @PutMapping("updateUser/{cnp}")
    public ResponseEntity<User> updateUser(@PathVariable(value = "cnp") long cnp, @RequestBody User updatedUser) {
        User user = adminService.updateUser(cnp, updatedUser);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
