package com.example.agencymvp.repository;

import com.example.agencymvp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {
    User findUserByUsernameAndPassword(String username, String password);

    List<User> findAll();

    User save (User user);

    void deleteByCnp(long cnp);

    User findByCnp(long cnp);





}
