package com.example.agencymvp.service;

import com.example.agencymvp.model.User;
import com.example.agencymvp.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    @Autowired
    private UserRepo userRepo;

    public User getByUserNameAndPassword(String username, String password){
        return userRepo.findUserByUsernameAndPassword(username,password);
    }
}
