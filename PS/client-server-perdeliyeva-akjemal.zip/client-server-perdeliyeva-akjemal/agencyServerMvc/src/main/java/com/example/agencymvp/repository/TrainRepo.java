package com.example.agencymvp.repository;

import com.example.agencymvp.model.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface TrainRepo extends JpaRepository<Train, Integer> {
    Train findByTrainNumber(int trainNumber);
    List<Train> findByDepartureStation(String departureStation);
    List<Train> findByDestination(String destination);
    List<Train>findByOrderByDepartureTimeAsc();
    List<Train>findAllByDepartureStationAndDestination(String departureStation, String destination);

    Train save(Train train);
    void deleteTrainByTrainNumber(int train);

    List<Train>findAll();

}
