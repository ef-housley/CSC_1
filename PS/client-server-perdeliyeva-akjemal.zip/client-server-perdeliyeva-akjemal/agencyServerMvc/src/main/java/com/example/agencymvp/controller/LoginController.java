package com.example.agencymvp.controller;

import com.example.agencymvp.model.User;
import com.example.agencymvp.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/login")
public class LoginController {
    @Autowired
    private LoginService loginService;

    @GetMapping("")
    public ResponseEntity<Map<String, String>> login(@RequestParam("username") String username, @RequestParam("password") String password) {
        User u = loginService.getByUserNameAndPassword(username, password);
        if (u != null) {
            Map<String, String> response = new HashMap<>();
            response.put("role", u.getRole());
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().build();
    }
}
