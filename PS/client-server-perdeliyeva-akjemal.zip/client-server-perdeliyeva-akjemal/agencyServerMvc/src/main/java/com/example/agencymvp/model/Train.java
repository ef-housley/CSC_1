package com.example.agencymvp.model;

import jakarta.persistence.*;
import lombok.*;


import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "trains")
public class Train implements Serializable {
    @Id
    @Column(name = "train_number", nullable = false)
    private int trainNumber;
    @Column(name = "departure_station")
    String departureStation;
    @Column(name = "destination")
    String destination;
    @Column(name = "departure_time")
    Date departureTime;
    @Column(name = "arrival_time", nullable= true )
    Date arrivalTime;
    @Column(name = "number_seat")
    int seatCapacity;
}