package com.example.agencymvp.model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "tickets")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ticket_number", nullable = false)
    private int ticketNumber;
    @Column(name = "seat_number")
    private int seatNumber;
    private double price;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "train_number")
    private Train trainNumber;
}
