package com.example.agencymvp.repository;

import com.example.agencymvp.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TicketRepo extends JpaRepository<Ticket, Integer> {
    boolean deleteByTicketNumber(int ticketNumber);
    Ticket findByTicketNumber(int ticketNumber);
    List<Ticket>findAll();
    Ticket save (Ticket ticket);
//    Ticket updateTicket(Ticket ticket);
}
