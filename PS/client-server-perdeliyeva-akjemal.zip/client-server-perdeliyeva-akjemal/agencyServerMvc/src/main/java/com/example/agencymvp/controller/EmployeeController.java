package com.example.agencymvp.controller;

import com.example.agencymvp.model.Ticket;
import com.example.agencymvp.model.Train;
import com.example.agencymvp.service.EmployeeService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/employee")
public class EmployeeController{

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public String welcome(){
        return "{\"message\": \"Welcome\"}";
    }

    @PostMapping("/addTrain")
    public Train addTrain(@RequestBody Train train) {
        return employeeService.addTrain(train);
    }

    @Transactional
    @PutMapping("deleteTrain/{trainNumber}")
    public void deleteTrain(@PathVariable(value = "trainNumber") int trainNumber) {
        employeeService.deleteTrain(trainNumber);
    }

    @GetMapping("/getAllTrains")
    public List<Train> getAllTrains(){
        return employeeService.getAllTrains();
    }

    @GetMapping("/getAllTickets")
    public List<Ticket> getAllTickets(){
        return employeeService.getAllTickets();
    }
}

