package com.example.agencymvp.service;

import com.example.agencymvp.model.User;
import com.example.agencymvp.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    UserRepo userRepo;

    public List<User> allUsers(){
        return userRepo.findAll();
    }

    public User addUser(User user){
        return userRepo.save(user);
    }

    public void deleteUser(long cnp){
        userRepo.deleteByCnp(cnp);
    }

    public User updateUser(long cnp, User updatedUser) {
        User user = userRepo.findByCnp(cnp);
        if (user != null) {
            user.setFirstname(updatedUser.getFirstname());
            user.setLastname(updatedUser.getLastname());
            user.setEmail(updatedUser.getEmail());
            user.setUsername(updatedUser.getUsername());
            user.setPassword(updatedUser.getPassword());
            user.setRole(updatedUser.getRole());
            return userRepo.save(user);
        } else {
            return null; // User with the given CNP not found
        }
    }
}
