package com.example.agencymvp.service;

import com.example.agencymvp.model.Train;
import com.example.agencymvp.repository.TrainRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PassengerService {

    @Autowired
    private TrainRepo trainRepo;


    public Train getByTrainNumber(int trainNumber) {
        return trainRepo.findByTrainNumber(trainNumber);
    }


    public List<Train> getByDepartureStation(String departureStation) {
        return trainRepo.findByDepartureStation(departureStation);
    }

    public List<Train> getByDestination(String destination) {
        return trainRepo.findByDestination(destination);
    }

    public List<Train> getAllOrderedByDepartureTime() {
        return trainRepo.findByOrderByDepartureTimeAsc();
    }

    public List<Train>getAllByDepartureStationBetween(String departureStation, String destination) {
        return trainRepo.findAllByDepartureStationAndDestination(departureStation,destination);
    }
}

