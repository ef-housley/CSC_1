package com.example.agencymvp.controller;

import com.example.agencymvp.model.Train;
import com.example.agencymvp.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/passenger")
public class PassengerController{

    @Autowired
    private PassengerService pService;


    @GetMapping("/{trainNumber}")
    public Train getByTrainNumber(@PathVariable("trainNumber") int trainNumber) {
        return pService.getByTrainNumber(trainNumber);
    }

    @GetMapping("/departureStation/{departureStation}")
    public List<Train> getByDepartureStation(@PathVariable("departureStation") String departureStation) {
        return pService.getByDepartureStation(departureStation);
    }

    @GetMapping("/destination/{destination}")
    public List<Train> getByDestination(@PathVariable("destination") String destination) {
        return pService.getByDestination(destination);
    }

    @GetMapping("/orderByDepartureTime")
    public List<Train> getAllOrderedByDepartureTime() {
        return pService.getAllOrderedByDepartureTime();
    }

    @GetMapping("/betweenStations/{departureStation1}/{departureStation2}")
    public List<Train> getAllByDepartureStationBetween(
            @PathVariable String departureStation1,
            @PathVariable String departureStation2
    ) {
        return pService.getAllByDepartureStationBetween(departureStation1, departureStation2);
    }
}

