package com.example.agencymvp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgencyServerAppTests {

    @Test
    void contextLoads() {
    }

}
